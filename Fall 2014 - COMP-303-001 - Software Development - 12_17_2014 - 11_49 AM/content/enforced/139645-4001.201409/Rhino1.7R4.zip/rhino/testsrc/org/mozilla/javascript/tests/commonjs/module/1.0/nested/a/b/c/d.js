exports.foo = function () {
    return 1;
};
