exports.foo = function() {};
