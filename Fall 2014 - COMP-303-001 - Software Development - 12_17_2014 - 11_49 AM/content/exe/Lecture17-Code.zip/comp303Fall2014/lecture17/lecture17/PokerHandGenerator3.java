package lecture17;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import lecture17.Card.Rank;
import lecture17.Card.Suit;

/**
 * @author Martin Robillard McGill University.
 * 
 * A Swing GUI application that is built as a subclass of JFrame. A
 * good style for many medium-sized applications. Here listeners are 
 * built on-the-fly as anonymous classes. A good solution if the required
 * listeners are short. Note that they can be made short thanks to the
 * features of the Java language, which bundle a reference to the parent 
 * object and the final local variables of the declaring methods into 
 * the instance of the anonymous class.
 * 
 * This program, like the two previous versions, also demonstrates the 
 * use of the Observer, Composite, Strategy, and Decorator patterns. 
 * See embedded comments.
 * 
 * I also forgot about straights that are not also flushes. I leave
 * that one as an exercise.
 * 
 * Note that this is not technically the right way to
 * launch a Swing application: I will complete this 
 * code in class.
 */
@SuppressWarnings("serial")
public class PokerHandGenerator3 extends JFrame
{
	private static final String TITLE = "Poker Hand Generator";
	
	private Card[] aCards = new Card[5];
	
	public static void main(String[] args)
	{
		new PokerHandGenerator3();
	}
	
	public PokerHandGenerator3()
	{	
		super(TITLE);
		
		// Layouts are strategies. Pick the one that creates the
		// type of layout you want.
		// JPanels are composite in the Composite design patterns.
		JPanel cardPanel = new JPanel();
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(3,1));
		
		setLayout(new BorderLayout());
		
		// Scrollable is a decorator
		add(new JScrollPane(cardPanel), BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		
		final JLabel[] labels = new JLabel[5];
		ImageIcon image = CardImages.getBack();
		for( int i = 0; i < 5; i++ )
		{
			labels[i] = new JLabel();
			labels[i].setIcon(image);
			cardPanel.add(labels[i]);
		}
		
		final JLabel aInfo = new JLabel(" ");
	
		aInfo.setHorizontalAlignment(SwingConstants.CENTER);
		bottomPanel.add(aInfo);
		JButton deal = new JButton("Deal");
		
		// Action Listeners are observers.
		deal.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				dealHand(aCards); 
				for( int i = 0; i < 5; i++ )
				{
					labels[i].setIcon(CardImages.getCard(aCards[i]));
				}	
			}
		});
		
		JButton reveal = new JButton("Reveal");
		bottomPanel.add(deal);
		bottomPanel.add(reveal);
		reveal.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if( aCards[0] != null)
				{
					aInfo.setText(describeHand());
				}		
			}
		});
		
		// This anonymous class actually inherits from a class,
		// instead of implementing an interface. Why is this useful? 
		cardPanel.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent pEvent)
			{
				// Demo code: Not industry-strength. Makes strong assumptions that
				// the layout of the application will remain as it is.
				Object source = pEvent.getSource();
				if( source instanceof JPanel )
				{
					Component component = ((JPanel)source).getComponentAt(pEvent.getPoint());
					if( component instanceof JLabel )
					{
						JLabel selected = (JLabel)component;
						for( int i = 0; i < 5; i++ )
						{
							if( labels[i] == selected )
							{
								if( aCards[i] != null )
								{
									aInfo.setText(aCards[i].toString());
								}
								break;
							}
						}
					}
				}				
			}
		});
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		
		System.out.println("PokerHandGenerator Launched...");
	}
	
	// Now this is a private instance method
	private void dealHand(Card[] pHand)
	{
		Deck deck = new Deck();
		for( int i = 0; i < 5; i++ )
		{
			aCards[i] = deck.draw();
		}
		Arrays.sort(aCards);
	}
	
	private String describeHand()
	{
		Suit suit = aCards[0].getSuit();
		for( int i = 1; i < 5; i++ )
		{
			if( aCards[i].getSuit() != suit)
			{
				suit = null;
				break;
			}
		}
		if( suit != null )
		{
			int lDelta = 0;
			for( int i = 1; i < 5; i++ )
			{
				lDelta += (aCards[i].getRank().ordinal() - aCards[i-1].getRank().ordinal());
			}
			if( lDelta == 4) return "Straight Flush";
			else return "Flush";
		}
		HashMap<Rank, Integer> cards = new HashMap<Rank,Integer>();
		for( Card card : aCards )
		{
			int count = 0;
			if( cards.containsKey(card.getRank()))
			{
				count = cards.get(card.getRank());
			}
			count++;
			cards.put(card.getRank(), count);
		}
		int lPairs = 0;
		int lTriples = 0;
		int lQuads = 0;
		for( int count : cards.values())
		{
			if( count == 2 ) lPairs++;
			else if( count == 3 ) lTriples++;
			else if( count == 4 ) lQuads++;
		}
		if( lQuads > 0 ) return "Four-of-a-kind";
		else if( lTriples > 0 )
		{
			if( lPairs > 0 ) return "Full House";
			else return "Three-of-a-kind";
		}
		else if( lPairs ==2 ) return "Two pairs";
		else if( lPairs == 1 ) return "Pair";
		else return "High card";
	}
}

