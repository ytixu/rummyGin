package lecture17;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import lecture17.Card.Rank;
import lecture17.Card.Suit;

/**
 * @author Martin Robillard McGill University.
 * 
 * A Swing GUI application that is built as a subclass of JFrame. A
 * good style for many medium-sized applications. The main application
 * object is also the Listener for all actions. This design leads to good
 * encapsulation but poor separation of concerns? Why? Don't forget 
 * the small blanket in the cold cabin.
 * 
 * I also forgot about straights that are not also flushes. I leave
 * that one as an exercise.
 * 
 * Note that this is not technically the right way to
 * launch a Swing application: I will complete this 
 * code in class.
 */
@SuppressWarnings("serial")
public class PokerHandGenerator2 extends JFrame implements ActionListener
{
	private static final String TITLE = "Poker Hand Generator";
	
	private Card[] aCards = new Card[5];
	private JLabel[] aLabels;
	private JLabel aInfo;
	
	public static void main(String[] args)
	{
		new PokerHandGenerator2();
	}
	
	public PokerHandGenerator2()
	{	
		super(TITLE);
		JPanel cardPanel = new JPanel();
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(3,1));
		
		setLayout(new BorderLayout());
		add(cardPanel, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		
		aLabels = new JLabel[5];
		ImageIcon image = CardImages.getBack();
		for( int i = 0; i < 5; i++ )
		{
			aLabels[i] = new JLabel();
			aLabels[i].setIcon(image);
			cardPanel.add(aLabels[i]);
		}
		aInfo = new JLabel(" ");
		aInfo.setHorizontalAlignment(SwingConstants.CENTER);
		bottomPanel.add(aInfo);
		JButton deal = new JButton("Deal");
		
		deal.addActionListener(this);
		
		JButton reveal = new JButton("Reveal");
		bottomPanel.add(deal);
		bottomPanel.add(reveal);
		reveal.addActionListener(this);
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		
		System.out.println("PokerHandGenerator Launched...");
	}
	
	// Now this is a private instance method
	private void dealHand()
	{
		Deck deck = new Deck();
		for( int i = 0; i < 5; i++ )
		{
			aCards[i] = deck.draw();
		}
		Arrays.sort(aCards);
	}

	@Override
	public void actionPerformed(ActionEvent pEvent)
	{
		if(((JButton)pEvent.getSource()).getText()=="Deal")
		{
			dealHand(); // now this is no longer static
			aInfo.setText(" ");
			for( int i = 0; i < 5; i++ )
			{
				aLabels[i].setIcon(CardImages.getCard(aCards[i]));
			}
		}
		else
		{
			if( aCards[0] != null)
			{
				aInfo.setText(describeHand());
			}
		}
	}
	
	private String describeHand()
	{
		Suit suit = aCards[0].getSuit();
		for( int i = 1; i < 5; i++ )
		{
			if( aCards[i].getSuit() != suit)
			{
				suit = null;
				break;
			}
		}
		if( suit != null )
		{
			int lDelta = 0;
			for( int i = 1; i < 5; i++ )
			{
				lDelta += (aCards[i].getRank().ordinal() - aCards[i-1].getRank().ordinal());
			}
			if( lDelta == 4) return "Straight Flush";
			else return "Flush";
		}
		HashMap<Rank, Integer> cards = new HashMap<Rank,Integer>();
		for( Card card : aCards )
		{
			int count = 0;
			if( cards.containsKey(card.getRank()))
			{
				count = cards.get(card.getRank());
			}
			count++;
			cards.put(card.getRank(), count);
		}
		int lPairs = 0;
		int lTriples = 0;
		int lQuads = 0;
		for( int count : cards.values())
		{
			if( count == 2 ) lPairs++;
			else if( count == 3 ) lTriples++;
			else if( count == 4 ) lQuads++;
		}
		if( lQuads > 0 ) return "Four-of-a-kind";
		else if( lTriples > 0 )
		{
			if( lPairs > 0 ) return "Full House";
			else return "Three-of-a-kind";
		}
		else if( lPairs ==2 ) return "Two pairs";
		else if( lPairs == 1 ) return "Pair";
		else return "High card";
	}
}

