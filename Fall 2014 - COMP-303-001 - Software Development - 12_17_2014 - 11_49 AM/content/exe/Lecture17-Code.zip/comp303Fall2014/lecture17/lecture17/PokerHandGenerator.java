package lecture17;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import lecture17.Card.Rank;
import lecture17.Card.Suit;

/**
 * @author Martin Robillard McGill University.
 * 
 * A Swing GUI application in the "procedural" style. Provided
 * to illustrate how Swing applications can be built any which way,
 * including badly. Observe the poor encapsulation in this design.
 * 
 * I also forgot about straights that are not also flushes. I leave
 * that one as an exercise.
 * 
 * Note that this is not technically the right way to
 * launch a Swing application: I will complete this 
 * code in class.
 *
 */
public class PokerHandGenerator
{
	private static final String TITLE = "Poker Hand Generator";
	
	public static void main(String[] args)
	{
		JFrame frame = new JFrame(TITLE);
		JPanel cardPanel = new JPanel();
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(3,1));
		
		frame.setLayout(new BorderLayout());
		frame.add(cardPanel, BorderLayout.CENTER);
		frame.add(bottomPanel, BorderLayout.SOUTH);
		
		JLabel[] labels = new JLabel[5];
		ImageIcon image = CardImages.getBack();
		for( int i = 0; i < 5; i++ )
		{
			labels[i] = new JLabel();
			labels[i].setIcon(image);
			cardPanel.add(labels[i]);
		}
		
		JLabel info = new JLabel(" ");
		info.setHorizontalAlignment(SwingConstants.CENTER);
		bottomPanel.add(info);
		JButton deal = new JButton("Deal");
		
		Card[] hand = new Card[5];
		
		deal.addActionListener(new DealListener(labels, hand, info));
		
		JButton reveal = new JButton("Reveal");
		bottomPanel.add(deal);
		bottomPanel.add(reveal);
		reveal.addActionListener(new RevealListener(hand, info));
		
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
		System.out.println("PokerHandGenerator Launched...");
	}
	
	public static void dealHand(Card[] pHand)
	{
		Deck deck = new Deck();
		for( int i = 0; i < 5; i++ )
		{
			pHand[i] = deck.draw();
		}
		Arrays.sort(pHand);
	}
}

class DealListener implements ActionListener
{
	private Card[] aCards;
	private JLabel[] aLabels;
	private JLabel aLabel;
	
	public DealListener(JLabel[] pLabels, Card[] pCards, JLabel pLabel )
	{
		aCards = pCards;
		aLabels = pLabels;
		aLabel = pLabel;
	}

	@Override
	public void actionPerformed(ActionEvent pEvent)
	{
		PokerHandGenerator.dealHand(aCards);
		for( int i = 0; i < 5; i++ )
		{
			aLabel.setText("");
			aLabels[i].setIcon(CardImages.getCard(aCards[i]));
		}
	}

}

class RevealListener implements ActionListener
{
	private Card[] aCards;
	private JLabel aLabel;
	
	public RevealListener(Card[] pCards, JLabel pLabel)
	{
		aCards = pCards;
		aLabel = pLabel;
	}

	@Override
	public void actionPerformed(ActionEvent pEvent)
	{
		if( aCards[0] != null)
			aLabel.setText(describeHand());
	}
	
	private String describeHand()
	{
		Suit suit = aCards[0].getSuit();
		for( int i = 1; i < 5; i++ )
		{
			if( aCards[i].getSuit() != suit)
			{
				suit = null;
				break;
			}
		}
		if( suit != null )
		{
			int lDelta = 0;
			for( int i = 1; i < 5; i++ )
			{
				lDelta += (aCards[i].getRank().ordinal() - aCards[i-1].getRank().ordinal());
			}
			if( lDelta == 4) return "Straight Flush";
			else return "Flush";
		}
		HashMap<Rank, Integer> cards = new HashMap<Rank,Integer>();
		for( Card card : aCards )
		{
			int count = 0;
			if( cards.containsKey(card.getRank()))
			{
				count = cards.get(card.getRank());
			}
			count++;
			cards.put(card.getRank(), count);
		}
		int lPairs = 0;
		int lTriples = 0;
		int lQuads = 0;
		for( int count : cards.values())
		{
			if( count == 2 ) lPairs++;
			else if( count == 3 ) lTriples++;
			else if( count == 4 ) lQuads++;
		}
		if( lQuads > 0 ) return "Four-of-a-kind";
		else if( lTriples > 0 )
		{
			if( lPairs > 0 ) return "Full House";
			else return "Three-of-a-kind";
		}
		else if( lPairs ==2 ) return "Two pairs";
		else if( lPairs == 1 ) return "Pair";
		else return "High card";
	}
	
}


