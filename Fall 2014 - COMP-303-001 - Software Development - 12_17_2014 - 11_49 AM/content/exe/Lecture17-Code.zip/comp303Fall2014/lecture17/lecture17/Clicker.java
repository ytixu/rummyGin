package lecture17;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * @author Martin Robillard McGill University
 * 
 * A minimalistic GUI program to demonstrate 
 * the connection between event handlers and 
 * widgets (components). Not a good example of 
 * design for larger applications.
 * 
 * Note that this is not technically the right way to
 * launch a Swing application: I will complete this 
 * code in class.
 */
public class Clicker
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		final JButton button = new JButton("Click");
		frame.add(button);
						
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
		System.out.println("Just launched the Clicker!");
		
		int count = 0;
		while(true)
		{
			button.setText("Count " + count++);
		}
	}
}