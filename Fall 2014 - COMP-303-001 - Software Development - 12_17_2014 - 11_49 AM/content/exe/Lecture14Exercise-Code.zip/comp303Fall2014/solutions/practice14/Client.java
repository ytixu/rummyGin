package practice14;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This code is a skeleton of a solution to the Scheduler problem.
 * I only include the code necessary to instantiate and assemble 
 * all the relevant parts of the problems. 
 */
public class Client
{
	/**
	 * Demonstration code. The exception is on purpose.
	 */
	public static void main(String[] args) throws SchedulingException
	{
		Location location1 = new Location("McGill");
		Location location2 = new Location("Concordia");
		Location location3 = new Location("UofM");
		Scheduler scheduler = new DefaultScheduler();
		scheduler.addObserver(new Logger());
		scheduler.add(new Biker("Billy Bob"));
		scheduler.add(new Biker("Mary Ann"));
		
		scheduler.schedule(location1);
		scheduler.schedule(location2);
		scheduler.schedule(location3);
	}
}

/**
 * In the original problem formulation.
 */
interface Scheduler
{
	void add(Biker pBiker);
	void schedule(Location pLocation) throws SchedulingException;
	void addObserver(SchedulerObserver pObserver);
}

/**
 * Implements very basic scheduling behavior: pick the first
 * biker in the list, and just ignore the location for the purpose
 * of schedling. We still need to include the location as a parameter
 * though, so that overriding methods can use the information.
 */
class DefaultScheduler implements Scheduler
{
	protected ArrayList<Biker> aAvailable = new ArrayList<>();
	protected HashMap<Biker, Location> aScheduled = new HashMap<>();
	private ArrayList<SchedulerObserver> aObservers = new ArrayList<>();
	
	public void add(Biker pBiker)
	{
		aAvailable.add(pBiker);
	}
	
	public void addObserver(SchedulerObserver pObserver)
	{
		aObservers.add(pObserver);
	}
	
	/* 
	 * This is the actual template method. Notice that it's final.
	 * @see practice14.Scheduler#schedule(practice14.Location)
	 */
	@Override
	public final void schedule(Location pLocation) throws SchedulingException
	{
		if( !checkAvailable() )
		{
			throw new SchedulingException();
		}
		
		notifyObservers(scheduleBiker(pLocation), pLocation);
	}
	
	/**
	 * I made this method private, but it could be public if 
	 * there was a need for it.
	 */
	private boolean checkAvailable()
	{
		return !aAvailable.isEmpty();
	}
	
	private void notifyObservers(Biker pBiker, Location pLocation)
	{
		for( SchedulerObserver observer : aObservers )
		{
			observer.bikerScheduled(pBiker, pLocation);
		}
	}
	
	/**
	 * In some instances of the TEMPLATE METHOD DESIGN PATTERN,
	 * the root class is abstract and this placeholder method is 
	 * often declared abstract because there is no obvious implementation
	 * for it. Here however, we can provide a default, albeit simplistic 
	 * behavior for the step.
	 */
	protected Biker scheduleBiker(Location pLocation)
	{
		return aAvailable.remove(0);
	}
}

class Biker
{
	private String aName;
	
	public Biker(String pName)
	{
		aName = pName;
	}
	
	@Override
	public String toString()
	{
		return aName;
	}
}

// In a more realistic implementation, this would include
// maybe an address and/or GPS coordinates, but here I keep
// it simple because the point is just to demo the design pattern.
class Location
{
	private String aDescription;
	
	public Location(String pDescription)
	{
		aDescription = pDescription;
	}
	
	@Override
	public String toString()
	{
		return aDescription;
	}
}

@SuppressWarnings("serial")
class SchedulingException extends Exception
{}

/**
 * An example of the push method.
 */
interface SchedulerObserver
{
	public void bikerScheduled(Biker pBiker, Location pLocation);
}

class Logger implements SchedulerObserver
{
	@Override
	public void bikerScheduled(Biker pBiker, Location pLocation)
	{
		System.out.println(pBiker + " dispatched to " + pLocation);		
	}
}