package lecture06;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class Reflector
{
	private static final String DAY_NAME = "lecture06.Day";
	
	public static void main(String[] args) throws Exception
	{
		Day day = new Day(2014,1,1);
		Class<?> cday = Class.forName(DAY_NAME);
		Class<?> cday1 = Day.class;
		
		Class<?> ssuper = cday.getSuperclass();
		
		for(Method m : cday.getDeclaredMethods())
		{
			System.out.println(m.getName());
		}
		
		Class<?> clazz = Class.class;
		
		Annotation[] ann = cday.getAnnotations();
		System.out.println(ann.length);
	}
}
