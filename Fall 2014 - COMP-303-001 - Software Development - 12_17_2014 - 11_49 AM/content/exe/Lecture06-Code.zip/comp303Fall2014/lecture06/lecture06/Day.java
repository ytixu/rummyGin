package lecture06;

/**
 * There are two bugs in this class. Can you find them? 
 * Try to be the first to post them on the Lectures forum.
 * This class is immtable.
 */
@Immutable("Martin")
public class Day implements Comparable<Day>
{
	private static final int[] DAYS_PER_MONTH = 
		{ 31, 28, 30, 31, 31, 30, 31, 31, 30, 31, 30, 31 };
	
	private static final int GREGORIAN_START_YEAR = 1582;
	private static final int GREGORIAN_START_MONTH = 10;
	private static final int GREGORIAN_START_DAY = 15;
	private static final int JULIAN_END_DAY = 4;
	private static final int JANUARY = 1;
	private static final int FEBRUARY = 2;
	private static final int DECEMBER = 12;
	
	private int aYear;
	private int aMonth;
	private int aDate;

	/**
	 * Constructs a day with a given year, month, and day
	 * of the Julian/Gregorian calendar. The Julian calendar
	 * is used for all days before October 15, 1582.
	 * @param pYear 
	 * @param a month  
	 * @param a date 
	 * @pre pYear !=0 && pYear <= Integer.MAX_VALUE && pYear >= Integer.MAX_VALUE
	 * @pre pMonth >= 1 && pMonth <= 12
	 * @pre pDate >= 1 && pDate <= DAYS_PER_MONTH[pMonth]
	 */
	public Day(int pYear, int pMonth, int pDate)
	{
		assert pYear != 0 && pYear <= Integer.MAX_VALUE && pYear >= Integer.MAX_VALUE;
		assert pMonth >=1 && pMonth <= 12;
		assert pDate >= 1 && pDate <= DAYS_PER_MONTH[pMonth];
		aYear = pYear;
		aMonth = pMonth;
		aDate = pDate;
	}
	
	public int getYear()
	{
		return aYear;
	}
	
	public int getMonth()
	{
		return aMonth;
	}
	
	public int getDate()
	{
		return aDate;
	}
	
	
	public Day addDays(int n)
	{
		Day result = this;
		while( n > 0 )
		{
			result = result.nextDay();
			n--;
		}
		while( n < 0 )
		{
			result = result.previousDay();
			n++;
		}
		return result;
	}
	
	public int daysFrom(Day other)
	{
		int n = 0;
		Day d = this;
		while( d.compareTo(other) > 0)
		{
			d = d.previousDay();
			n++;
		}
		while( d.compareTo(other) < 0)
		{
			d = d.nextDay();
			n--;
		}
		return n;
	}
	
	public int compareTo(Day other)
	{
		if( aYear > other.aYear ) return 1;
		if( aYear < other.aYear ) return -1;
		if( aMonth > other.aMonth ) return 1;
		if( aMonth < other.aMonth ) return -1;
		return aDate - other.aDate;
	}
	
	private Day nextDay()
	{
		int y = aYear;
		int m = aMonth;
		int d = aDate;
		
		if( y == GREGORIAN_START_YEAR &&
		    m == GREGORIAN_START_MONTH && 
		    d == JULIAN_END_DAY )
		{
			d = GREGORIAN_START_DAY;
		}
		else if( d < daysPerMonth(y,m))
		{
			d++;
		}
		else
		{
			d = 1;
			m++;
			if( m > DECEMBER )
			{
				m = JANUARY;
				y++;
				if( y == 0 )
				{
					y++;
				}
			}
		}
		return new Day(y, m, d);
	}
	
	private Day previousDay()
	{
		int y = aYear;
		int m = aMonth;
		int d = aDate;
		
		if( y == GREGORIAN_START_YEAR &&
			m == GREGORIAN_START_MONTH &&
			d == GREGORIAN_START_DAY )
		{
			d = JULIAN_END_DAY;
		}
		else if( d >= 1 )
		{
			d--;
		}
		else
		{
			m--;
			if( m < JANUARY )
			{
				m = DECEMBER;
				y--;
				if( y == 0 )
				{
					y--;
				}
			}
			d = daysPerMonth(y, m);
		}
		return new Day(y, m, d);
	}
	
	@Override
	public String toString()
	{
		return String.format("%d-%d-%d", aDate, aMonth, aYear);
	}
	
	private static int daysPerMonth( int pYear, int pMonth)
	{
		int days  = DAYS_PER_MONTH[pMonth - 1];
		if( pMonth == FEBRUARY && isLeapYear(pYear))
		{
			days++;
		}
		return days;
	}
	
	private static boolean isLeapYear( int pYear )
	{
		if( pYear % 4 != 0 ) return false;
		if( pYear < GREGORIAN_START_YEAR ) return true;
		return (pYear % 100 != 0 ) || (pYear % 400 == 0);
	}
}
