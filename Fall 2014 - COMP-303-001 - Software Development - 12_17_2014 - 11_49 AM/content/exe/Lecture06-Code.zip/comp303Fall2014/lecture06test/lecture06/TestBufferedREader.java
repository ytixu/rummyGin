package lecture06;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.Test;

public class TestBufferedREader
{
	@Test(expected=FileNotFoundException.class)
	public void testIt() throws Exception
	{
		BufferedReader in = new BufferedReader(new FileReader("Foowawa"));
		in.close();
	}
}
