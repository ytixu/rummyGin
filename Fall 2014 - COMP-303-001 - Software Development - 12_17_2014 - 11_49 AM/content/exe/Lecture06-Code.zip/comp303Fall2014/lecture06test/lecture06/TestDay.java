package lecture06;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestDay
{
	private Day aDay;
	
	@Before
	public void setup()
	{
		aDay = new Day(2014,1,2);
	}

	@Test
	public void testConstructor()
	{
		assertEquals(2014,aDay.getYear());
		assertEquals(2,aDay.getDate());
		assertEquals(1,aDay.getMonth());
	}
	
	@Test
	public void testAddDaysBasicPositive()
	{
		Day day1 = aDay.addDays(1);
		assertEquals(3,day1.getDate());
	}
	
	@Test
	public void testAddDaysBasicNegative()
	{
		Day day1 = aDay.addDays(-1);
		assertEquals(1,day1.getDate());
	}
	
	@Test
	public void testAddDaysNegativeMultiple()
	{
		Day day = new Day(2014,2,3);
		Day day1 = aDay.addDays(-4);
		assertEquals(2014,day1.getYear());
		assertEquals(1,day1.getMonth());
		assertEquals(30,day.getDate());

	}
}
