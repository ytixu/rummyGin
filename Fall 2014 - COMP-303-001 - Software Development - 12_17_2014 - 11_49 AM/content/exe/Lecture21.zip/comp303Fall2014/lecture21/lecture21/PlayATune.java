package lecture21;


public class PlayATune
{
	public static void main(String[] args)
	{
		MyTune.play();
		while(true)
		{
			System.out.println("Sweet");
			System.out.println("   Georgia");
			System.out.println("      Brown");
		}
	}
}
