package lecture21;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class CheeseShop extends JFrame
{
	// Some cheeses are missing - you can add them in
	private static final String[] CHEESES = {"Red Leicester", "Tilsit", "Caerphilly", 
		"Bel Paese", "Red Windsor", "Stilton", "Gruy�re", "Emmental", "Jarlsberg", "Liptauer",
		"Lancashire", "White Stilton", "Danish Blue", "Double Gloucester", "Cheshire",
		"Dorset Blue Vinney"};
	
	private static final String[] RESPONSES = {"I'm afraid we're fresh out of it sir.", 
		"Never at the end of the week, sir. Always get it fresh first thing on Monday.",
		"Ah well, it's been on order for two weeks, sir. I was expecting it this morning.",
		"Sorry",
		"Normally, but today the van broke down.",
		"No",
		"Not today sir, no.",
		"Well, I'm afraid we don't get much call for it around these parts."};
	
	private final Random aRandom = new Random();
	
	public CheeseShop()
	{
		super("Cheese Shop");
		FlowLayout layout = new FlowLayout();
		layout.setAlignment(FlowLayout.LEFT);
		setLayout(layout);
		add(new JLabel("How about..."));
		final JButton button = new JButton(CHEESES[aRandom.nextInt(CHEESES.length)]); 
		button.setPreferredSize(new Dimension(180,25));
		add(button);
		
		final JLabel response = new JLabel();
		response.setPreferredSize(new Dimension(300,25));
		add(response);
		
		button.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				response.setText(RESPONSES[aRandom.nextInt(RESPONSES.length)]);		
			}
		});
		
		new Timer(1000, new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				button.setText(CHEESES[aRandom.nextInt(CHEESES.length)]);		
			}
		}).start();
		
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		setLocationRelativeTo(null);
		pack();
		setVisible( true );
	}
	
	public static void main(String[] args)
	{
		new CheeseShop();
	}
}
