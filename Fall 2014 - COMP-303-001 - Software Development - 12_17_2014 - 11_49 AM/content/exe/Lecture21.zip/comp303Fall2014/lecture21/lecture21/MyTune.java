package lecture21;


import java.io.File;

import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;

public class MyTune 
{
	public static void play()
	{
		try
		{
			BasicPlayer lPlayer = new BasicPlayer();
			lPlayer.open( new File("c:\\temp\\georgia.mp3"));
			lPlayer.play();
			while(true)
			{
				System.out.println("------");
				System.out.println(" 0000");
			}
		}
		catch( BasicPlayerException pException )
		{
			pException.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		MyTune.play();
	}
}
