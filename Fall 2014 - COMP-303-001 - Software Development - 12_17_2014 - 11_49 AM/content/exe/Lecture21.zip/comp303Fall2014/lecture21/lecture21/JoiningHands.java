package lecture21;

/**
 * "Done" unpredictably appears at the beginning or the end of the run,
 * without join.
 *
 */
public class JoiningHands
{
	public static void main(String[] args)
	{
		Thread t1 = new Thread( new Runnable()
		{
			public void run()
			{
				for( int i = 0; i < 10000; i++ )
				{
					System.out.println("pif");
				}
			}
		});
				
		t1.start();
		try
		{
			t1.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("Done");
	}
}