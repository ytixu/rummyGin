package lecture21;

/**
 * Demonstrates that if the only threads left are daemon threads, the JVM shuts down.
 */
public class Deamons
{
	public static void main( String[] args )
	{
		Thread t1 = new Thread( new Runnable(){

			public void run()
			{
				while( true ) System.out.println("----------");
				
			}});
		Thread t2 = new Thread( new Runnable(){

			public void run()
			{
				int i = 30000;
				while( i-- > 0 ) System.out.println("0000000000000000000000000000000000000000000");
				
			}});
		
		t1.setDaemon( true );
		t1.start();
		t2.start();
	}
}
