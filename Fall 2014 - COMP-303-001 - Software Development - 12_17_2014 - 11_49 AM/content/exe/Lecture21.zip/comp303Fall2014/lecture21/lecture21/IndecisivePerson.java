package lecture21;

/**
 * Exercise: Define your own parameterized runnable class that
 * endlessly prints a given message, and use it to reduce code duplication
 * in this example.
 */
public class IndecisivePerson
{
	public static void main(String[] args)
	{
		new Thread( new Runnable()
			{
				
				@Override
				public void run()
				{
					while(true)
					{
						System.out.println("Maybe Not");
						try{
						Thread.sleep(500);
						}
						catch(InterruptedException e ) { return; }
					}
					
				}
			}).start();
			
		new Thread( new Runnable()
		{
			
			@Override
			public void run()
			{
				while(true)
				{
					System.out.println("Maybe");
					try{
						Thread.sleep(500);
						}
						catch(InterruptedException e ) { return; }
				}
				
			}
		}).start();
			
	}
	
}
