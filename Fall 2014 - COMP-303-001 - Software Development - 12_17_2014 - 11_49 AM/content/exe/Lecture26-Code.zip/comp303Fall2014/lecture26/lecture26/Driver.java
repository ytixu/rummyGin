package lecture26;

public class Driver
{
	public static void main(String[] args)
	{
		BoundedBuffer buffer = new BoundedBuffer();
		Thread t1 = new Thread(new Taker(buffer));
		Thread t2 = new Thread(new Taker(buffer));
		Thread t3 = new Thread(new Taker(buffer));
		Thread p1 = new Putter(buffer);
		Thread p2 = new Putter(buffer);
		Thread p3 = new Putter(buffer);
		p1.start();
		p2.start();
		p3.start();
		t1.start();
		t2.start();
		t3.start();
		
	}
}

class Taker implements Runnable
{
	private BoundedBuffer aBuffer;
	
	public Taker(BoundedBuffer pBuffer)
	{
		aBuffer = pBuffer;
	}
	
	@Override
	public void run()
	{
		for( int i = 0; i < 100000; i++)
		{
			try{ aBuffer.take(); }
			catch( InterruptedException e ) { return; }
		}
	}
}

class Putter extends Thread
{
	private BoundedBuffer aBuffer;
	
	public Putter(BoundedBuffer pBuffer)
	{
		aBuffer = pBuffer;
		setDaemon(true);
	}
	
	@Override
	public void run()
	{
		while(true)
		{
			try{ aBuffer.put("Something"); }
			catch( InterruptedException e ) { return; }
		}
	}
}