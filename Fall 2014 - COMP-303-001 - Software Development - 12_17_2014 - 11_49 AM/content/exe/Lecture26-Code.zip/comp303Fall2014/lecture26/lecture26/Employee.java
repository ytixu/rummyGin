package lecture26;

import java.util.ArrayList;
import java.util.List;

public class Employee implements IPerson
{
	private String aName;
	
	public String getName()
	{
		return aName;
	}
	
	public void accept(Visitor v)
	{
		v.visitEmployee(this);
	}
}

interface IPerson
{
	String getName();
	void accept(Visitor v);
}

class Manager extends Employee
{
	private List<Employee> aEmployees = new ArrayList<>();
	
	public void add(Employee e )
	{
		aEmployees.add(e);
	}
	
	public void accept(Visitor v)
	{
		v.visitManager(this);
		for( Employee e : aEmployees ) e.accept(v);
	}
	
	public IPerson search(String pQuery)
	{
		SearchVisitor v = new SearchVisitor(pQuery);
		accept(v);
		return v.getResult();
	}
}

interface Visitor
{
	void visitEmployee(Employee e );
	void visitManager(Manager m);
}

class SearchVisitor implements Visitor
{
	private String aQuery;
	private IPerson aResult;
	
	public SearchVisitor(String pQuery)
	{
		aQuery = pQuery;
	}
	
	@Override
	public void visitEmployee(Employee e)
	{
		if( e.getName().equals(aQuery))
		{
			aResult = e;
		}
	}

	@Override
	public void visitManager(Manager m)
	{
		if( m.getName().equals(aQuery))
		{
			aResult = m;
		}
	}
	
	public IPerson getResult()
	{
		return aResult;
	}
}