package lecture26;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestAbs
{
	@Test
	public void testAll()
	{
		assertEquals(1,Math.abs(1));
		assertEquals(Integer.MAX_VALUE, Math.abs(Integer.MAX_VALUE));
		
		assertEquals(0,Math.abs(0));
		
		assertEquals(2, Math.abs(-2));
		assertEquals(Integer.MIN_VALUE, Math.abs(Integer.MIN_VALUE));
		assertEquals(-(Integer.MIN_VALUE+1), Math.abs(Integer.MIN_VALUE+1));
	}
}
