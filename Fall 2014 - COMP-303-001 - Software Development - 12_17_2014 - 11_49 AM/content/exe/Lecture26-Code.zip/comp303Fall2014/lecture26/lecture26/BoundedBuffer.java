package lecture26;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedBuffer
{
	private final Lock aLock = new ReentrantLock();
	private final Condition aNotFull = aLock.newCondition();
	private final Condition aNotEmpty = aLock.newCondition();

	final Object[] aItems = new Object[100];
	int aPutIndex = 0;
	int aTakeIndex = 0;
	int aCount = 0;
	
	public void put(Object o) throws InterruptedException
	{
		aLock.lock();
		
		try
		{
			while( aCount == aItems.length ) aNotFull.await();
			aItems[aPutIndex] = o;
			if( ++aPutIndex == aItems.length ) 
			{
				aPutIndex = 0;
			}
			++aCount;
			aNotEmpty.signalAll();
		}
		finally
		{
			aLock.unlock();
		}
	}
	
	public Object take() throws InterruptedException
	{
		aLock.lock();
		
		try
		{
			while( aCount == 0 ) aNotEmpty.await();
			
			Object x = aItems[aTakeIndex];
			if(++aTakeIndex == aItems.length)
			{
				aTakeIndex = 0;
			}
			--aCount;
			aNotFull.signalAll();
			return x;
		}
		finally
		{
			aLock.unlock();
		}
	}
}
