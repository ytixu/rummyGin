package ca.mcgill.cs.comp303fall2013.lecture04;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;

import ca.mcgill.cs.comp303fall2013.lecture04.Card.Rank;
import ca.mcgill.cs.comp303fall2013.lecture04.Card.Suit;

public class Player implements Iterable<Card>
{
	private String aName;
	private int aScore;
	private Date aBirthDate;
	private ArrayList<Card> aHand = new ArrayList<Card>();
	
	public Player(String pName, Date pBirthDate)
	{
		aName = pName;
		aBirthDate = pBirthDate;
		aScore = 0;
	}
	
	public void add(Card pCard) { aHand.add(pCard); }
	public String getName() { return aName; }
	public Date getBirthDate() { return (Date) aBirthDate.clone(); }
	public void addToScore(int pIncrement) { aScore += pIncrement; }
	public int getScore() { return aScore; }
//	public List<Card> getHand() { return Collections.unmodifiableList(aHand); }
	
	public String toString()
	{
		return String.format("%s born %tF score=%d cards=%s" , aName, aBirthDate, aScore, Arrays.toString(aHand.toArray()));
	}
	
	public static Comparator<Player> getByNameComparator()
	{
		return new Comparator<Player>() {
			public int compare(Player p1, Player p2)
			{
				return p1.getName().compareTo(p2.getName());
			}
		};
	}
	
	
	
	public static void main(String[] args)
	{
		Date date = genDate(1,0,1980);
		Player player = new Player("Bob", date);
		player.add(new Card(Rank.ACE, Suit.CLUBS));
		player.add(new Card(Rank.TWO, Suit.CLUBS));
		player.add(new Card(Rank.THREE, Suit.CLUBS));
		player.add(new Card(Rank.FOUR, Suit.CLUBS));
//		System.out.println(player);
				
//		for(Card card : player)
//		{
//			System.out.println(card);
//		}
		
		Player[] players = new Player[3];
		players[0] = player;
		players[1] = generateP1();
		players[2] = generateP2();
		
		
		Arrays.sort(players, new Comparator<Player>()
				{
					public int compare(Player p1, Player p2)
					{
						return p1.getName().compareTo(p2.getName());
					}
				});
		
		Arrays.sort(players, Player.getByNameComparator());
		
		for(Player p : players)
		{
			System.out.println(p);
		}
	}		
	
	// --- Harness code --- //
	
	private static Date genDate(int pDay, int pMonth, int pYear)
	{
		Calendar cal = Calendar.getInstance();
		cal.set(pYear, pMonth, pDay);
		return cal.getTime();
	}

	private static Player generateP1()
	{
		Date date = genDate(1,3,1980);
		Player player = new Player("Alice", date);
		player.add(new Card(Rank.ACE, Suit.DIAMONDS));
		player.add(new Card(Rank.TWO, Suit.DIAMONDS));
		player.add(new Card(Rank.THREE, Suit.DIAMONDS));
		player.add(new Card(Rank.FOUR, Suit.DIAMONDS));
		player.addToScore(10);
		return player;
	}
	
	private static Player generateP2()
	{
		Date date = genDate(1,3,1975);
		Player player = new Player("Carl", date);
		player.add(new Card(Rank.ACE, Suit.HEARTS));
		player.add(new Card(Rank.TWO, Suit.HEARTS));
		player.add(new Card(Rank.THREE, Suit.HEARTS));
		player.add(new Card(Rank.FOUR, Suit.HEARTS));
		player.addToScore(100);
		return player;
	}

	@Override
	public Iterator<Card> iterator()
	{
		return aHand.iterator();
	}
}