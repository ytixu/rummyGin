package p02;


/**
 * Shows how to call super constructors.
 */
public class Employee
{
	private String aName;
	private int aSalary;
	
	public String getName()
	{
		return aName;
	}
	
	public Employee()
	{
		System.out.println("Employee default constructor");
	}
	
	public Employee(String pName, int pSalary) 
	{ aName = pName; aSalary = pSalary; }
	
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		Manager alice = new Manager();
		Manager bob = new Manager("Bob", 10000000, 1000000);
	}
}

class Manager extends Employee
{
	private int aBonus;
	
	public Manager()
	{
		System.out.println("Manager default constructor");
	}
	
	public Manager(String pName, int pSalary, int pBonus)
	{
		super(pName, pSalary);
		aBonus = pBonus;
	}
	
	public String toString()
	{
		return getName() + aBonus;
	}
}