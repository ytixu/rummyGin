package p05;

public class Employee
{
	private String aName;
	protected int aSalary;
		
	/**
     * @pre pSalary >= 100000
	 */
	public Employee( String pName, int pSalary )
	{
		aName = pName;
		aSalary = pSalary;
	}
	
	public int getSalary()
	{
		return aSalary;
	}
	
	public int baselineIncrements()
	{
		return aSalary / 100000;
	}
}

