package p05;

public class Manager extends Employee
{
	public Manager(String pName, int pSalary)
	{
		super(pName, pSalary);
	}
	
	public void reduceSalary()
	{
		aSalary = aSalary - aSalary / 10;
	}
	
}

