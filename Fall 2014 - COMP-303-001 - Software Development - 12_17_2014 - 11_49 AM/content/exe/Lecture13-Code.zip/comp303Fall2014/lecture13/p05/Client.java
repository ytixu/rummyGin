package p05;

/**
 * Demonstrates how to break the Liskov Substitutability Principle
 *
 */
public class Client
{
	public static void main(String[] args)
	{
		Manager bob = new Manager("Bob", 100000);
		bob.reduceSalary();
		System.out.println(bonus(bob));
	}
	
	private static double bonus(Employee pEmployee)
	{
		return 10000/pEmployee.baselineIncrements();
	}
}
