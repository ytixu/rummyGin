package p08;

/**
 * Illustrates a case where inheritance is used for composition.
 * Source: Java Puzzlers
 */
class Counter
{
	private static int count;
	public static void increment() { count++; }
	public static int getCount() { return count; }
}

class Dog extends Counter 
{
	public void woof() { increment(); }
}

class Cat extends Counter
{
	public void meow() { increment(); }
}

public class Ruckus
{
	public static void main(String[] args)
	{
		Dog[] dogs = { new Dog(), new Dog() };
		Cat[] cats = { new Cat(), new Cat(), new Cat() };
		for( Dog dog : dogs ) dog.woof();
		for( Cat cat : cats ) cat.meow();
		System.out.println(String.format("%d woofs and %d meows", Dog.getCount(), Cat.getCount()));
	}
}
