package p07;

public class Client
{
	public static void main(String[] args)
	{
		Employee e1 = new Employee("Alice");
		Employee e2 = new Manager("Alice");
		compareThem(e1,e2);
	}
	
	public static void compareThem(Employee e1, Employee e2)
	{
		System.out.println(e1.equals(e2));
		System.out.println(e2.equals(e1));
		System.out.println(e2.equals(e2.clone()));
	}
}
