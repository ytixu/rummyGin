package p07;

public class Employee implements Cloneable
{
	protected String aName;
		
	public Employee( String pName )
	{ aName = pName; }
	
	public String getName()
	{ return aName; }
	
	@Override
	public boolean equals(Object pObject)
	{
		if( pObject == null ) return false;
		if( pObject == this ) return true;
		if( !(pObject instanceof Employee )) return false;
		return aName.equals(((Employee)pObject).getName());
	}
	
	@Override
	public int hashCode()
	{
		return aName.hashCode();
	}
	
	@Override 
	public Employee clone()
	{
		return new Employee(getName());
	}
}



class Manager extends Employee
{
	public Manager(String pManager)
	{
		super(pManager);
	}
	
	@Override
	public boolean equals(Object pObject)
	{
		if( pObject == null ) return false;
		if( pObject == this ) return true;
		if( !(pObject instanceof Manager )) return false;
		return aName.equals(((Employee)pObject).getName());
	}
}
