package p03;


public class Overloader
{
	public static void main(String[] args)
	{
		System.out.println(new Overloader().doit("Foo"));
		String foo = "Foo";
		new Overloader().redirector(foo);
	}
	
	public void redirector(Object p)
	{
		System.out.println(new Overloader().doit(p));
	}
	
	public void doit(int p) {  }
	public String doit(long p) { return "long"; }
	public String doit(double p) { return "double"; }
	public String doit(Employee p) { return "Employee"; }
	public String doit(String p) { return "String"; }
	public String doit(Object p) { return "Object"; }
}
