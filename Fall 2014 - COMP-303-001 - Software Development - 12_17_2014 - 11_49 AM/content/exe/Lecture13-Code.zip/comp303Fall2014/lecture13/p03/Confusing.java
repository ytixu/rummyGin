package p03;

/**
 * Illustrates that overloading can be pretty confusing.
 * double[] gets called because it's the most specific of 
 * all applicable methods, based on the static type of p.
 * Source: Java Puzzlers
 */
public class Confusing
{
	public Confusing( Object p )
	{
		System.out.println("Object");
	}
	
	public Confusing( double[] p )
	{
		System.out.println("Double array");
	}
	
	public static void main(String[] args)
	{
		new Confusing(null);
	}
}
