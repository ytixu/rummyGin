package p03;

public class Employee
{
	private String aName;
	private int aSalary;
}

class Programmer extends Employee
{
	
}

class Manager extends Employee
{
	private int aBonus;
}