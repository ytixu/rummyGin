package lecture25;

public interface IVisitable
{
	void accept(Visitor pVisitor);
}
