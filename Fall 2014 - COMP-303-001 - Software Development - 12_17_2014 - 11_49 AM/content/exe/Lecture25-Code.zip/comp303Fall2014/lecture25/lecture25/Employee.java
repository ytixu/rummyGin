package lecture25;

import java.util.ArrayList;
import java.util.List;

public class Employee
{
	public void accept(EmployeeVisitor pVisitor)
	{
		pVisitor.visitEmployee(this);
	}
}

class Manager extends Employee
{
	private List<Employee> aEmployees = new ArrayList<Employee>();
	
	public void accept(EmployeeVisitor pVisitor)
	{
		pVisitor.visitEmployee(this);
	}
}

interface EmployeeVisitor
{
	public void visitEmployee(Employee pEmployee);
	public void visitManager(Manager pManager);
}