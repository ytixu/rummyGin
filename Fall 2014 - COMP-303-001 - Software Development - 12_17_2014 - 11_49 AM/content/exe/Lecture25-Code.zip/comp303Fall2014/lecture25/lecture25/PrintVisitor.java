package lecture25;

public class PrintVisitor extends DefaultVisitor
{
	private String aPrefix = " ";
	
	@Override
	public void visitUniversity(University pUniversity)
	{
		System.out.println(aPrefix + pUniversity.getName());
		aPrefix += " ";
		super.visitUniversity(pUniversity);
		aPrefix = aPrefix.substring(1);
	}

	@Override
	public void visitFaculty(Faculty pFaculty)
	{
		System.out.println(aPrefix + pFaculty.getName());

		aPrefix += " ";
		super.visitFaculty(pFaculty);
		aPrefix = aPrefix.substring(1);
	}

	@Override
	public void visitDepartment(Department pDepartment)
	{
		System.out.println(aPrefix + pDepartment.getName());
		aPrefix += " ";
		super.visitDepartment(pDepartment);
		aPrefix = aPrefix.substring(1);
	}

	@Override
	public void visitCommittee(Committee pCommittee)
	{
		System.out.println(aPrefix + pCommittee.getName());
		aPrefix += " ";
		super.visitCommittee(pCommittee);
		aPrefix = aPrefix.substring(1);
	}
	
}
