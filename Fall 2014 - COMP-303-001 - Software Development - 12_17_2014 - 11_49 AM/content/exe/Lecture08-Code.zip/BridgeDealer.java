package lecture08;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class BridgeDealer extends JFrame
{
	private final Deck aDeck;
	
	public BridgeDealer()
	{
		super("Bridge Hand Dealer \u00A9 Martin Robillard 2014");
		
		aDeck = new Deck();
		
		final HandPanel aNorth = new HandPanel();
		final HandPanel aSouth = new HandPanel();
		
		JPanel lPanel = new JPanel();
		lPanel.setLayout(new GridLayout(2, 1));
		lPanel.add(aNorth);
		lPanel.add(aSouth);
		setLayout(new BorderLayout());
		add(lPanel, BorderLayout.CENTER);
		
		final JButton deal = new JButton("Deal");
		add(deal, BorderLayout.SOUTH);
		deal.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				aDeck.reset();
				aDeck.shuffle();	
				aNorth.showHand(dealHand());
				aSouth.showHand(dealHand());
			}
		});
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setResizable(false);
		setVisible(true);
	}

	public static void main(String[] args)
	{
		new BridgeDealer();
	}
	
	private Card[] dealHand()
	{
		Card[] lReturn = new Card[13];
		for( int i = 0; i < 13; i++)
		{
			lReturn[i] = aDeck.draw();
		}
		Arrays.sort(lReturn);
		return lReturn;
	}
}

class HandPanel extends JPanel
{
	private static final int SHIFT = 30; // Recommended horizontal shift
	
	private JLabel aLabel = new JLabel();
	
	public HandPanel()
	{
		setBackground(new Color(0,102,0));
		add(aLabel);
		// TODO Create a composite icon of the back 
		// of 13 cards
		aLabel.setIcon(CardImages.getBack());
	}
	
	public void showHand(Card[] pHand)
	{
		// TODO You want to compose your icon for the hand here
		aLabel.setIcon(CardImages.getCard(pHand[0]));
	}
}
