package lecture15;

@SuppressWarnings("serial")
public class ConversionException extends Exception
{
	public ConversionException() {}
	
	public ConversionException(String pMessage) { super(pMessage); }
}
