package lecture15;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Good news from Java 7
 */
public class EHDemo3
{
	public void doit2()
	{
		try( BufferedReader in = new BufferedReader(new FileReader("data.txt")); 
			 PrintWriter out = new PrintWriter( new FileWriter("data2.txt")))
		{
			String line = in.readLine(); // If IOException raised here, closed 
			out.println(line);
		}
		catch( IOException e )
		{
			e.printStackTrace(); // Don't do this at home
		}
	}
}
