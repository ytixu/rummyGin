package lecture15;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.util.Random;

/**
 * This demonstration code shows how different checked exceptions 
 * require different catch clauses, and how the catch clause is selected
 * based on the run-type type of the object that can be bound to the 
 * catch clause, as checked in lexical order.
 */
public class EHDemo1
{
	public static void doit()
	{
		String foo = null;
		if( new Random().nextBoolean() ) foo = "Foo";
		foo.equals("Foo");
//		mayThrowEOF();
//		mayThrowFileNotFoundException();
	}

	public static void mayThrowEOF() throws EOFException
	{
		if( new Random().nextBoolean() ) throw new EOFException();
	}
	
	public static void mayThrowFileNotFoundException() throws FileNotFoundException
	{
		if( new Random().nextBoolean() ) throw new FileNotFoundException();
	}
	
}
