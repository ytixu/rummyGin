package lecture15;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Wrapping
 */
public class EHDemo4
{
	public void doit2(String pNumber) throws MyException
	{
		try
		{
			Integer.parseInt(pNumber);
		}
		catch( NumberFormatException e )
		{
			throw new MyException(e);
		}
	}
}

class MyException extends Exception
{
	public MyException(Throwable t)
	{
		super(t);
	}
}
