package lecture15;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * An old version of the LuckyNumber application see in
 * lecture 12, but with less good input validation, and 
 * used to demonstrate error-handling principles.
 */
@SuppressWarnings("serial")
public class Observationificator extends JFrame
{
	/**
	 * Builds and launches the GUI.
	 */
	public Observationificator()
	{
		setTitle("Observationificator");
		// The first parameter below is the number of 
		// rows in the main window. To add one, change 3 to 4.
		setLayout(new GridLayout(3, 1));
		
		// This can be a local because we're storing a reference
		// directly inside the panels.
		Model lModel = new Model();
		
		add(new SliderPanel(lModel));  	// Top component
		add(new IntegerPanel(lModel)); 	// Middle component
		add(new TextPanel(lModel));   	// Bottom component\
//		add(new SliderPanel(lModel));  	// Top component

		
		setDefaultCloseOperation(EXIT_ON_CLOSE); // Activates the close button.
		pack(); 						// Computes optimal size of the window
		setLocationRelativeTo(null);	// Sticks the window in the middle of the screen
		setVisible(true);
	}
	
	public static void main(String[] args) throws IOException
	{
		new Observationificator();
	}
}

@SuppressWarnings("serial")
class SliderPanel extends JPanel implements Observer, ChangeListener
{
	private JSlider aSlider = new JSlider();
	private Model aModel;
	
	public SliderPanel(Model pModel)
	{
		aModel = pModel;
		aModel.addObserver(this);
		aSlider.setMinimum(0);
		aSlider.setMaximum(10);
		aSlider.setPaintTicks(true);
		aSlider.setMajorTickSpacing(1);
		aSlider.setSnapToTicks(true);
		aSlider.setValue(aModel.getNumber());
		aSlider.addChangeListener(this);
		add(aSlider);
	}
	
	@Override
	public void stateChanged(ChangeEvent e)
	{
		aModel.setNumber(aSlider.getValue());				
	}

	@Override
	public void newNumber(int pNumber)
	{
		aSlider.setValue(pNumber);
	}
}

@SuppressWarnings("serial")
class IntegerPanel extends JPanel implements Observer, ActionListener
{
	private JTextField aText = new JTextField(20);
	private Model aModel;
	
	public IntegerPanel(Model pModel)
	{
		aModel = pModel;
		aModel.addObserver(this);
		aText.setText(new Integer(aModel.getNumber()).toString());
		aText.addActionListener(this);
		add(aText);
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		aModel.setNumber(Converter.fromNumber(aText.getText()));
	}

	@Override
	public void newNumber(int pNumber)
	{
		aText.setText(new Integer(aModel.getNumber()).toString());
		
	}
}

class Converter
{
	private static final String[] LABELS = {"Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"};
	
	public static int fromNumber(String pNumber)
	{
		return Integer.parseInt(pNumber);
	}
	
	public static int fromText(String pNumber)
	{
		for( int i = 0; i < LABELS.length; i++)
		{
			if(pNumber.equalsIgnoreCase(LABELS[i]))
			{
				return i;
			}
		}
		return Integer.MAX_VALUE;
	}
	
	public static String toText(int pNumber)
	{
		return LABELS[pNumber];
	}
}

@SuppressWarnings("serial")
class TextPanel extends JPanel implements Observer, ActionListener
{
	private JTextField aText = new JTextField(20);
	private Model aModel;

	public TextPanel(Model pModel)
	{
		aModel = pModel;
		aModel.addObserver(this);
		aText.setText(Converter.toText(aModel.getNumber()));
		aText.addActionListener(this);
		add(aText);
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		try {
		aModel.setNumber(Converter.fromText(aText.getText()));}
		catch( NumberFormatException ex)
		{
			JOptionPane.showMessageDialog(this, ex.getMessage());
		}
	}

	@Override
	public void newNumber(int pNumber)
	{
		aText.setText(Converter.toText(aModel.getNumber()));
	}
}

class Model
{
	private ArrayList<Observer> aObservers = new ArrayList<Observer>();
	private int aNumber = 5;
	
	public void addObserver(Observer pObserver)
	{
		aObservers.add(pObserver);
	}
	
	private void notifyObservers()
	{
		for(Observer observer : aObservers)
		{
			observer.newNumber(aNumber);
		}
	}
	
	public void setNumber(int pNumber)
	{
		aNumber = pNumber;
		notifyObservers();
	}
	
	public int getNumber()
	{
		return aNumber;
	}
}

interface Observer
{
	void newNumber(int pNumber);
}