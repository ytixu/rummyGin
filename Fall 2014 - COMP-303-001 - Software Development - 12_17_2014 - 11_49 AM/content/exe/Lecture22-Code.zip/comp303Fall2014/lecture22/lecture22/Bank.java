package lecture22;

import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class Bank
{
	public static void main( String[] args )
	{
		final Account[] accs = new Account[50];
		final Random r = new Random();
		for( int i = 0 ; i < accs.length; i++ ) accs[i] = new Account(20000);
		Thread[] threads = new Thread[1000];
		
		for( int i = 0; i < 1000; i++ )
		{
			threads[i] = new Thread( new Runnable()
			{
				public void run()
				{
					for( int j = 0 ; j < 10000; j++)
					{
						accs[r.nextInt(50)].debit(10);
						accs[r.nextInt(50)].credit(10);
					}
				}
			});
		}
		for( int i = 0; i < 1000; i++ )
		{
			threads[i].start();
		}
		
		waitUntilThreadsAreDone(threads);
		
		int s = 0;
		for( Account a : accs ) s+=a.getBalance();
		System.out.println(s);
	}
	
	private static void waitUntilThreadsAreDone(Thread[] pThreads)
	{
		
	}
}
