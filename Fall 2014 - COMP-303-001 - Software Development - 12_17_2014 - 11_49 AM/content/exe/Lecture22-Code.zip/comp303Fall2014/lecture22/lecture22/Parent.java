package lecture22;

import java.util.Random;

public class Parent implements Runnable
{
	private Account aAccount;
	public Parent(Account pAccount){ aAccount = pAccount; }
	
	public void run()
	{
		for( int i = 0 ; i < 1000; i++ )
		{
			try
			{
				aAccount.credit(1000);
				Thread.sleep(250);
				System.out.println("Week " + i + " balance " + aAccount.getBalance());
			}
			catch( InterruptedException e )
			{
				return;
			}
		}
		
	}
	
	public static void main( String[] args )
	{
		Account account = new Account(0);
		new Thread( new Parent(account)).start();
		new Thread( new Teen(account,100)).start();
		new Thread( new Teen(account,150)).start();
		new Thread( new Teen(account,200)).start();
	}
}

class Teen implements Runnable
{
	private Account aAccount;
	private int aAllowance;
	private Random aRandom = new Random();
	
	public Teen(Account pAccount, int pAllowance)
	{
		aAccount = pAccount;
		aAllowance = pAllowance;
	}
	
	public void run()
	{
		for( int i = 0; i < 150; i++ )
		{
			int lSpend = aRandom.nextInt(aAllowance);
			while( lSpend > aAccount.getBalance())
			{
				Thread.yield();
			}
			aAccount.debit(lSpend);
		}
	}
}