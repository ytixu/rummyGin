package lecture22;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Shared data structure for my synchronization examples.
 */
public class Account
{
	private int aBalance;
	
	public Account( int pInitialBalance ) 
	{ aBalance = pInitialBalance; }
	
	public  void credit( int pAmount ) 
	{ 
		aBalance += pAmount;
	}
	
	public  void debit( int pAmount ) 
	{ 
		aBalance -= pAmount;
	} 
	
	public  int getBalance() 
	{ 
		return aBalance;
	}
}
