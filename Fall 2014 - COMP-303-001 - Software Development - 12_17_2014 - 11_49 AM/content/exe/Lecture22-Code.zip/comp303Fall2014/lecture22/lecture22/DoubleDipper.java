package lecture22;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread safe int wrapper. Demonstrates reentrancy.
 * In addsome, the same thread can reacquire the same lock.
 * 
 * With a reentrant lock, if a thread tries acquire
 * a lock it already has, the request succeeds.
 */
public class DoubleDipper
{
	private int aBalance = 0;
	private final Lock aLock = new ReentrantLock();
	
	public int getBalance()
	{
		try
		{
			aLock.lock();
			return aBalance;
		}
		finally
		{
			aLock.unlock();
		}
	}
	
	public void addSome()
	{
		try
		{
			aLock.lock();
			if( getBalance() < 10000 )
			{
				aBalance++;
				System.out.println(aBalance);
			}
		}
		finally
		{
			aLock.unlock();
		}
	}

	public static void main(String[] args)
	{
		final DoubleDipper dd = new DoubleDipper();
		for( int i = 0; i < 1000; i++ )
		{
			new Thread( new Runnable()
			{
				@Override
				public void run()
				{
					while(true)
					{
						dd.addSome();
					}
				}
			}).start();
		}
	}
}
