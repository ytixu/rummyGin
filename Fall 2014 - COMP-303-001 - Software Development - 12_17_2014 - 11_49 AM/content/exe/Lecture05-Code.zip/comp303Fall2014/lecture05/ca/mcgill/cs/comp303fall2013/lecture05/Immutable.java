package ca.mcgill.cs.comp303fall2013.lecture05;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Immutable
{
	String value();
}
