package ca.mcgill.cs.comp303fall2013.lecture05;


public class AbusiveClient
{
	public static void main(String[] args)
	{
	}
}
