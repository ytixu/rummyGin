package exerciseset05;

import java.util.ArrayList;

/**
 * This class plays the role of the model in the
 * Observer design pattern.
 */
public class Inventory
{
	private ArrayList<Item> aItems = new ArrayList<>();
	private ArrayList<InventoryObserver> aObservers = new ArrayList<>();
	
	public void addItem(Item pItem)
	{
		aItems.add(pItem);
		notifyObservers(pItem, true);
	}
	
	public void removeItem(Item pItem)
	{
		aItems.remove(pItem);
		notifyObservers(pItem, false);
	}
	
	public void addObserver(InventoryObserver pObserver)
	{
		aObservers.add(pObserver);
	}
	
	public void removeObserver(InventoryObserver pObserver)
	{
		aObservers.remove(pObserver);
	}
	
	private void notifyObservers(Item pItem, boolean pAdded)
	{
		for( InventoryObserver observer : aObservers)
		{
			observer.itemAddedOrRemoved(pItem, pAdded);
		}
	}
	
	/**
	 * This methods simulates the "client". It could be in
	 * any class. I just declare it in the Inventory class
	 * for convenience.
	 * @param args Not used.
	 */
	public static void main(String[] args)
	{
		Inventory inventory = new Inventory();
		inventory.addObserver(new ListView());
		PieChart chart = new PieChart();
		inventory.addObserver(chart);
		
		// A couple of operations that trigger callbacks
		// on both observers
		inventory.addItem(new Item(123,2014));
		inventory.addItem(new Item(456,2014));
		Item item = new Item(678, 1970);
		inventory.addItem(item);
		
		// Now let's disconnect the pie chart and remove an item
		inventory.removeObserver(chart);
		inventory.removeItem(item);
	}
}

class Item
{
	private int aSerialNumber;
	private int aProductionYear;
	
	public Item(int pSerialNumber, int pProductionYear)
	{
		aSerialNumber = pSerialNumber;
		aProductionYear = pProductionYear;
	}
	
	@Override
	public String toString()
	{
		return String.format("Number: %d Year: %d", aSerialNumber, aProductionYear);
	}
}

interface InventoryObserver
{
	/**
	 * The call back method. Notice how this method is not
	 * very well-designed according to the principles described in 
	 * Chapter 3 of the book, mostly because it tangles two potentially
	 * different types of events. In exercise set 06, you'll explore
	 * a more elegant solution.
	 * @param pItem The item that was added or removed.
	 * @param pAdded True if the item was added, false if removed.
	 */
	void itemAddedOrRemoved(Item pItem, boolean pAdded);
}

class ListView implements InventoryObserver
{
	@Override
	public void itemAddedOrRemoved(Item pItem, boolean pAdded)
	{
		// The details are not terribly important to the 
		// observer design pattern learning objectives.
		// Here I'll just do a println
		String action = "added to";
		if( !pAdded )
		{
			action = "removed from";
		}
		System.out.println(pItem + " was " + action + " the list view");
	}
}

class PieChart implements InventoryObserver
{
	@Override
	public void itemAddedOrRemoved(Item pItem, boolean pAdded)
	{
		// The details are not terribly important to the 
		// observer design pattern learning objectives.
		// Here I'll just do a println
		String action = "added to";
		if( !pAdded )
		{
			action = "removed from";
		}
		System.out.println(pItem + " was " + action + " the pie chart");
	}
}