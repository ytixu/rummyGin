package lecture15;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Finally
 */
public class EHDemo2
{
	public void doit() throws IOException
	{
		BufferedReader in = null;
		in = new BufferedReader(new FileReader("data.txt"));
		String line = in.readLine(); 
		in.close();
	}
	
	public void doit2() throws IOException
	{
		BufferedReader in = null;
		PrintWriter out = null;
		try {
		in = new BufferedReader(new FileReader("data.txt"));
		out = new PrintWriter( new FileWriter("data2.txt"));
		String line = in.readLine(); 
		out.println(line); }
		finally
		{
			if( in != null )
			{
				
				try{
					in.close();
				}
				finally {
					if( out != null )
					{
						out.close();
					}
				}
			}
		}
	}
	
	// Just put that in the finally
	public static void closeIgnoring(Closeable c)
	{
		if( c != null )
		{
			try
			{
				c.close();
			}
			catch( IOException e )
			{
				// log
			}
		}
	}
}
