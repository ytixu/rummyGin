package lecture18;

import java.util.HashMap;

/**
 * A demonstration of the Flyweight pattern. The question of 
 * how to get the data to initialize objects is not specified by
 * the pattern and left out here. The specific way to do this would
 * depend on the actual requirements.
 */
public class Country
{
	private static HashMap<String,Country> aCountries = new HashMap<>();
	
	private String aName;
	private int aPopulation;
	
	private Country(String pName, int pPopulation)
	{
		aName = pName;
		aPopulation = pPopulation;
	}
	
	public static Country getCountry(String pName)
	{
		Country country = aCountries.get(pName);
		if( country == null )
		{
			country = new Country(pName, 5000000);
			aCountries.put(pName, country);
		}
		return country;
	}
}
