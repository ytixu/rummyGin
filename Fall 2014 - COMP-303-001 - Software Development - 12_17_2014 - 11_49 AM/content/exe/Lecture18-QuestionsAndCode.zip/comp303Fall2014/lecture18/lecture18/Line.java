package lecture18;

/**
 * Code relates to Q7 of Midterm2005.
 */
public class Line
{
	private int aX1;
	private int aY1;
	private int aX2;
	private int aY2;
	
	public Line(int pX1, int pY1, int pX2, int pY2)
	{
		aX1 = pX1; aX2 = pX2; aY1 = pY1; aY2 = pY2;
	}
	
	public int getX1() { return aX1; }
	public int getX2() { return aX2; }
	public int getY1() { return aY1; }
	public int getY2() { return aY2; }
	
	public void setX1(int pX1) { aX1 = pX1; }
	public void setX2(int pX2) { aX2 = pX2; }
	public void setY1(int pY1) { aY1 = pY1; }
	public void setY2(int pY2) { aY2 = pY2; }

	public void move(int pDeltaX, int pDeltaY)
	{
		aX1 += pDeltaX; aX2 += pDeltaX;
		aY1 += pDeltaY; aY2 += pDeltaY;
	}
	
	public static void main(String[] args)
	{
		Point p = new Point(5,6);
		System.out.println(p.getX1() == p.getX2());
		p.setX1(345);
		System.out.println(p.getX1() == p.getX2());
	}
}

class Point extends Line
{
	public Point( int pX, int pY)
	{
		super(pX, pY, pX, pY);
	}
}