package lecture18;

import java.util.ArrayList;

public class World
{
	private static final World WORLD = new World();
	
	private final ArrayList<Country> aCountries = new ArrayList<>();
	
	private World(){}
	
	public static World instance(){return WORLD;}
}
