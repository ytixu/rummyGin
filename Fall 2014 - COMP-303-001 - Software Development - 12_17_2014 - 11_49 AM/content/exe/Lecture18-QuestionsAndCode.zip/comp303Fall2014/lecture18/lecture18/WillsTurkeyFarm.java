package lecture18;

import java.util.Date;

/**
 * You should be able to add InfectedTurkey to this as an exercise.
 */
public class WillsTurkeyFarm
{
	public static void main(String[] args)
	{
		// Create an ordinary turkey
		Turkey myTurkey = new OrdinaryTurkey(1, new Date());
		myTurkey.printReport();
		
		// Make it organic
		System.out.println();
		Turkey organic = new OrganicTurkey(myTurkey, 100, new Date());
		organic.printReport();
		
		// Make it free-range only
		System.out.println();
		Turkey freeRange = new FreeRangeTurkey(myTurkey, 1000);
		freeRange.printReport();
		
		// Make it organic and free-range
		System.out.println();
		Turkey happy = new FreeRangeTurkey(organic, 1000);
		happy.printReport();
		
		// Going too far and abusing the pattern.
		System.out.println();
		Turkey experimentalTurkey = new OrganicTurkey(happy, 100, new Date());
		experimentalTurkey.printReport();
	}
}

interface Turkey
{
	public void printReport();
}

class OrdinaryTurkey implements Turkey
{
	private int aId;
	private Date aBirthDate;
	
	public OrdinaryTurkey(int pId, Date pBirthDate)
	{
		aId = pId;
		aBirthDate = pBirthDate;
	}

	@Override
	public void printReport()
	{
		System.out.println("Id: " + aId);
		System.out.println("BirthDate: " + aBirthDate);
	}
}

class OrganicTurkey implements Turkey
{
	private Turkey aWrappedTurkey;
	private int aCertificationNumber;
	private Date aCertificationDate;
	
	public OrganicTurkey(Turkey pWrapped, int pCertNb, Date pCertDate)
	{
		aWrappedTurkey = pWrapped;
		aCertificationNumber = pCertNb;
		aCertificationDate = pCertDate;
	}
	
	@Override
	public void printReport()
	{
		aWrappedTurkey.printReport();
		System.out.println("Certification Number: " + aCertificationNumber);
		System.out.println("Certification Date: " + aCertificationDate);
	}
}

class FreeRangeTurkey implements Turkey
{
	private Turkey aWrappedTurkey;
	private int aRoamingTime;
	
	public FreeRangeTurkey(Turkey pWrapped, int pRoamingTime)
	{
		aWrappedTurkey = pWrapped;
		aRoamingTime = pRoamingTime;
	}
	
	@Override
	public void printReport()
	{
		aWrappedTurkey.printReport();
		System.out.println("Roaming Time: " + aRoamingTime);
	}
}