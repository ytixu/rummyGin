package lecture07;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

class Sheep
{
	private String aName;
	private Date aBirth;    // Date/Time of birth 
	public Sheep(String name) { aName = name; aBirth = new Date();}
	public void rename(String name) { aName = name; }
	public String getName() { return aName; }
	public void vocalize() { System.out.println("Baahaahaaah"); }
	public boolean equals(Object o) { return aName.equals(((Sheep)o).getName()); } // Don't do this at home!
	public int hashCode() { return aName.hashCode(); }
	
	public static void main(String[] args)
	{
		Flock flock = new Flock();
		Sheep schaun = new Sheep("Schaun");
		flock.add(schaun);
		System.out.println(flock.present(schaun));
		
		schaun.rename("Uncle Bob");
		System.out.println(flock.present(schaun));
	}
}


class Flock 
{
	Set<Sheep> aFlock = new HashSet<Sheep>();
	
	public void add ( Sheep a ) { aFlock.add( a ); }
	public boolean present ( Sheep a ) { return aFlock.contains(a); }
}
