package lecture07;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

public class ObjectUtilizer
{
	public static void main(String[] args)
	{
		Card card1 = new Card(Rank.ACE, Suit.CLUBS);
		Card card2 = new Card(Rank.ACE, Suit.CLUBS);
		
		System.out.println(card1.equals(card2));
	}
	
		
}
