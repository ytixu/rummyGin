package lecture07;

import java.util.ArrayList;
import java.util.HashSet;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

public class Player
{
	private ArrayList<Card> aCards = new ArrayList<Card>();
	
	public void add(Card pCard) { aCards.add(pCard); }
	
	public void remove(Card pCard) { aCards.remove(pCard); }
	
	public int size() { return aCards.size(); }
	
	public static void main(String[] args)
	{
//		Player player = new Player();
//		player.add( new Card(Rank.ACE, Suit.CLUBS) );
//		player.remove( new Card(Rank.ACE, Suit.CLUBS) );
//		System.out.println(player.size());
		
		HashSet<Card> cards = new HashSet<>();
		Card card = new Card(Rank.ACE, Suit.CLUBS);
		cards.add(card);
		System.out.println(cards.contains(new Card(Rank.ACE, Suit.CLUBS)));
	}
}	
