package lecture07;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

public class IdentityCrisis
{
	public static void main(String[] args) throws Exception
	{
		Card card1 = new Card(Rank.ACE, Suit.CLUBS);
		
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("card.dat"));
		out.writeObject(card1);
		out.writeObject(card1);
		out.close();
		
		ObjectInputStream in = new ObjectInputStream( new FileInputStream("card.dat"));
		Card card2 = (Card)in.readObject();
		Card card3 = (Card)in.readObject();
		in.close();
		
		System.out.println("Card 1 == Card 1: " + (card1 == card1));
		System.out.println("Card 2 == Card 3: " + (card2 == card3));
		System.out.println("Card 1 == Card 2: " + (card1 == card2));
		System.out.println("Card 1 == Card 3: " + (card1 == card3));
	}
}
