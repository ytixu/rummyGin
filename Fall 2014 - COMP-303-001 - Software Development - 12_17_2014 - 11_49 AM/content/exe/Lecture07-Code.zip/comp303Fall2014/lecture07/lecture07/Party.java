package lecture07;

import java.util.HashMap;


public class Party
{
	private static HashMap<String, Party> aParties = new HashMap<>();
	
	private String aName = "Nothing";

	
	private Party(String pName)
	{
		aName = pName;
	}
	
	public Party getParty(String pName)
	{
		// figure out if I have a party of that name
		if( !aParties.containsKey(pName))
		{
			aParties.put(pName, new Party(pName));
		}
		return aParties.get(pName);
	}
}
