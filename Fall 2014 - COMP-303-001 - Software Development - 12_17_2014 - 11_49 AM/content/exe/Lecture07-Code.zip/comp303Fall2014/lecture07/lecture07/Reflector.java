package lecture07;

import java.lang.reflect.Method;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

public class Reflector
{
	private static final String CARD_NAME = "lecture07.Card";
	
	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception
	{
		Card card1 = new Card(Rank.ACE, Suit.CLUBS);
		Card card2 = card1;
		Card card3 = new Card(Rank.ACE, Suit.CLUBS);
		Class<?> ccard1 = Class.forName(CARD_NAME);
		Class<?> ccard2 = Card.class;
		
//		System.out.println(card1 == card2);
		
		for(Method m : ccard1.getDeclaredMethods())
		{
			System.out.println(m.getName());
		}
		
	}
}
