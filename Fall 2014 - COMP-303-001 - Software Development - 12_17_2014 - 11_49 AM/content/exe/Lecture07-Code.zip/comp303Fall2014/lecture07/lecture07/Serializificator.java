package lecture07;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.google.gson.Gson;

public class Serializificator
{
	public static void main(String[] args) throws Exception 
	{
		Person doris = new Person("Doris");
		Person jack = new Person("Jack");
		Person gary = new Person("Gary");
		doris.setRomanticInterest(jack);
		jack.setRomanticInterest(gary);
//		gary.setRomanticInterest(doris);
		
//		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("triangle.dat"));
//		out.writeObject(doris);
//		out.close();
		
//		ObjectInputStream in = new ObjectInputStream( new FileInputStream("triangle.dat"));
//		Person doris2 = (Person)in.readObject();
//		in.close();
//		System.out.println(doris2);
//		System.out.println(doris2.getRI());
//		System.out.println(doris2.getRI().getRI());
		
		Person[] persons = new Person[2];
		Person bob = new Person("Bob");
		persons[0] = bob;
		persons[1] = doris;
		String out2 = new Gson().toJson(persons);
		System.out.println(out2);
	}
}

class Person implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8491277515651130820L;
	private String aName;
	private Person aRomanticInterest;
//	private Hobby ahobby;

	public Person(String pName) { aName = pName; }
	public String getName() { return aName; }
	public Person getRI() { return aRomanticInterest; }
	public void setRomanticInterest( Person pRI ) { aRomanticInterest = pRI; }
	public String toString() { return aName + " likes " + aRomanticInterest.getName(); }
}

class Hobby implements Serializable {
	private String name = "painting";
	
}