package lecture07;


import java.util.Collections;
import java.util.HashMap;
import java.util.Stack;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

/**
 * Models a deck of 52 cards (no joker).
 */
public class Deck 
{
	private static HashMap<Rank, HashMap<Suit, Card>> CARDS = new HashMap<Rank, HashMap<Suit, Card>>();
	
	private Stack<Card> aCards = new Stack<Card>();
	
	public static Card getCard(Rank pRank, Suit pSuit)
	{
		HashMap<Suit, Card> map = CARDS.get(pRank);
		if( map == null )
		{
			map = new HashMap<Suit, Card>();
			CARDS.put(pRank, map);
		}
		Card card = map.get(pSuit);
		if( card == null )
		{
			card = new Card(pRank, pSuit);
			map.put(pSuit, card);
		}
		return card;
	}
	
	public Deck()
	{
		reset();
	}

	public void reset()
	{
		aCards.clear();
		for(Suit suit : Suit.values())
		{
			for(Rank rank : Rank.values())
			{
				aCards.add(Deck.getCard(rank,  suit));
			}
		}
	}
	
	public void shuffle()
	{
		Collections.shuffle(aCards);
	}
	
	public Card draw()
	{
		return aCards.pop();
	}
	
	public int size()
	{
		return aCards.size();
	}
}
