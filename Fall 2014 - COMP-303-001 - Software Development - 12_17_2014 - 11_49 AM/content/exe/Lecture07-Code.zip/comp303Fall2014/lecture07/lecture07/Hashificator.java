package lecture07;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import lecture07.Card.Rank;
import lecture07.Card.Suit;

public class Hashificator
{
	public static void main(String[] args)
	{
		List<Card> list = new ArrayList<Card>();
		HashMap<Card, String> map = new HashMap<Card, String>();
		
		Card card1 = new Card(Rank.ACE, Suit.CLUBS);
		Card card2 = new Card(Rank.ACE, Suit.CLUBS);
		
		list.add(card1);
		list.remove(card2);
		System.out.println(list.size());
		
		map.put(card1, "First");
		map.remove(card2);
		System.out.println(map.size());
	}
}
